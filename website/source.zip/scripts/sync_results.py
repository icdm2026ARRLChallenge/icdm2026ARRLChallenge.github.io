"""Download public score-only snapshots; verify RSA signature before rendering."""
import argparse,hashlib,json,math,re,subprocess,tempfile,urllib.request,urllib.error
from datetime import datetime,timezone
from fractions import Fraction
from pathlib import Path
MAX=8*1024**2
ROOT=Path(__file__).resolve().parent.parent

def fetch(url):
 req=urllib.request.Request(url,headers={'User-Agent':'ICDM-results-sync/1.0','Cache-Control':'no-cache'})
 with urllib.request.urlopen(req,timeout=30) as r:
  b=r.read(MAX+1)
  if len(b)>MAX:raise ValueError('Snapshot exceeds limit')
  return b

def validate(p):
 if set(p)!={'schema_version','revision','cycle','cutoff','status','scorer_version','tasks'} or type(p['schema_version']) is not int or p['schema_version'] not in (1,2) or p['status']!='provisional' or p['scorer_version']!='2.1.0':raise ValueError('Unsupported snapshot')
 if type(p['revision']) is not int or p['revision']<1:raise ValueError('Invalid revision')
 cycle=datetime.fromisoformat(p['cycle'].replace('Z','+00:00'));cutoff=datetime.fromisoformat(p['cutoff'].replace('Z','+00:00'))
 if cycle.tzinfo is None or cutoff.tzinfo is None or cycle>datetime.now(timezone.utc) or cutoff>=cycle:raise ValueError('Invalid time window')
 if set(p['tasks'])!={'1','2'}:raise ValueError('Invalid tasks')
 for task,rows in p['tasks'].items():
  if not isinstance(rows,list) or len(rows)>10000:raise ValueError('Too many rows')
  names=['score','group_count_score_mean','group_membership_match_mean'] if task=='1' else ['event_discovery_score','type_classification_accuracy','event_count_score','event_membership_match']
  fields={'team_id','rank',*names,*(n+'_exact' for n in names)};seen=set();previous=None;rank=0;unranked=False;last_unranked=None
  if p['schema_version']==2:fields.add('status')
  for i,r in enumerate(rows,1):
   if not isinstance(r,dict) or not isinstance(r.get('team_id'),str) or not re.fullmatch(r'[A-Za-z0-9_]{1,64}',r['team_id']) or r['team_id'].lower() in seen:raise ValueError('Invalid public row')
   seen.add(r['team_id'].lower())
   if p['schema_version']==2 and r.get('status')!='valid':
    if set(r)!={'team_id','rank','status'} or r['rank'] is not None or r['status'] not in ('invalid_submission','pending','evaluation_error'):raise ValueError('Invalid unranked row')
    if last_unranked is not None and r['team_id']<last_unranked:raise ValueError('Unranked teams out of order')
    unranked=True;last_unranked=r['team_id'];continue
   if set(r)!=fields or unranked:raise ValueError('Valid rows must precede unranked rows')
   for n in names:
    v=r[n+'_exact']
    if set(v)!={'numerator','denominator'} or type(v['numerator']) is not int or type(v['denominator']) is not int or v['denominator']<=0:raise ValueError('Invalid exact metric')
    f=Fraction(v['numerator'],v['denominator'])
    if type(r[n]) not in (int,float) or not math.isfinite(r[n]) or not 0<=f<=(100 if n in ['score','event_discovery_score','type_classification_accuracy'] else 1) or abs(float(f)-r[n])>1e-9:raise ValueError('Metric mismatch')
   keys=['score'] if task=='1' else ['event_discovery_score','type_classification_accuracy']
   key=tuple(Fraction(r[n+'_exact']['numerator'],r[n+'_exact']['denominator']) for n in keys)
   if previous is not None and key>previous:raise ValueError('Out of order')
   if key!=previous:rank=i
   if type(r['rank']) is not int or r['rank']!=rank:raise ValueError('Rank mismatch')
   previous=key
 return p

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--url',required=True);parser.add_argument('--current-url',required=True);parser.add_argument('--force',action='store_true');args=parser.parse_args()
 try:manifest=json.loads(fetch(args.url+'/manifest.json'))
 except urllib.error.HTTPError as e:
  if e.code==404 and datetime.now(timezone.utc)<datetime(2026,10,20,12,tzinfo=timezone.utc):print('changed=true' if args.force else 'changed=false');return
  raise
 digest=manifest.get('sha256','')
 if not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Invalid manifest')
 body=fetch(args.url+'/'+digest+'.json');sig=fetch(args.url+'/'+digest+'.sig')
 if hashlib.sha256(body).hexdigest()!=digest:raise ValueError('Digest mismatch')
 with tempfile.TemporaryDirectory() as temp:
  a=Path(temp)/'payload';b=Path(temp)/'signature';a.write_bytes(body);b.write_bytes(sig)
  subprocess.run(['openssl','dgst','-sha256','-verify',str(ROOT/'data/publish-public.pem'),'-signature',str(b),str(a)],check=True,stdout=subprocess.DEVNULL)
 p=validate(json.loads(body));old=None
 try:old=json.loads(fetch(args.current_url))
 except urllib.error.HTTPError as e:
  if e.code!=404:raise
 if old:
  if p['revision']<old['revision']:raise ValueError('Refusing rollback to an older signed snapshot')
  if p['revision']==old['revision'] and p!=old:raise ValueError('Conflicting revision')
 (ROOT/'data/live-leaderboard.json').write_bytes(body)
 print('changed='+str(args.force or old!=p).lower())
if __name__=='__main__':main()
