"""Explicit allowlist; deployment artifacts never include backend or runtime data."""
from pathlib import Path
import shutil
import re
root = Path(__file__).resolve().parent.parent
out = root / '_site'
if out.exists():
    shutil.rmtree(out)
out.mkdir()
for name in ('index.html', '.nojekyll'):
    shutil.copy2(root / name, out / name)
for name in ('assets', 'pages', 'results'):
    # These legacy portraits are not used by any page.
    shutil.copytree(root / name, out / name, ignore=shutil.ignore_patterns('organizers') if name == 'assets' else None)
assert not (out / 'pages/admin.html').exists()
for p in out.rglob('*'):
    if p.is_file() and (p.is_symlink() or p.suffix in ('.sqlite', '.zip', '.pt', '.pem', '.csv') or p.name.startswith('.env')):
        raise ValueError('Unexpected public artifact: ' + str(p))
# Render public results into static pages to avoid iframe navigation restrictions.
css = (root / 'results/style.css').read_text()
def scope_css(match):
    selector = match.group(1)
    if selector.strip().startswith('@'):
        return selector + '{'
    return ','.join('.embedded-results' if v.strip() in ('html','body','main') else '.embedded-results ' + v.strip() for v in selector.split(',')) + '{'
(out / 'assets/results-static.css').write_text(re.sub(r'([^{}]+)\{', scope_css, css))
for name in ('leaderboard', 'prizes'):
    page = out / 'pages' / (name + '.html')
    text = page.read_text()
    def embed(match):
        source = re.search(r'src="([^"]+)"', match.group(0)).group(1)
        result = (page.parent / source).resolve()
        if result.parent != (out / 'results').resolve():
            raise ValueError('Unexpected results source')
        content = re.search(r'<main>(.*?)</main>', result.read_text(), re.S).group(1)
        return '<div class="embedded-results">' + content + '</div>'
    text, count = re.subn(r'<iframe\b[^>]*>.*?</iframe>', embed, text, flags=re.S)
    if count != 1:
        raise ValueError('Expected one results block')
    text = text.replace('<script src="../assets/results-embed.js"></script>', '')
    text = text.replace('</head>', '<link rel="stylesheet" href="../assets/results-static.css"></head>')
    page.write_text(text)

print('Public-only GitHub Pages artifact:', out)

for p in out.rglob('*.html'):
    text = p.read_text()
    csp = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-src 'self'; connect-src 'none'; object-src 'none'; base-uri 'self'; form-action 'none'"
    text = text.replace('<head>', '<head><meta http-equiv="Content-Security-Policy" content="' + csp + '"><meta name="referrer" content="no-referrer">', 1)
    p.write_text(text)
# Only the validated, public score snapshot is copied; never private reports or references.
live = root / 'data/live-leaderboard.json'
if live.exists():
    import json
    from sync_results import validate
    validate(json.loads(live.read_text()))
    shutil.copy2(live, out / 'results/current.json')
