from pathlib import Path
import csv, json, math, re
from datetime import datetime, timezone, timedelta
from html import escape
ROOT=Path(__file__).resolve().parent.parent
AOE=timezone(timedelta(hours=-12))
def aoe_stamp(date):
 return date.astimezone(AOE).strftime('%B %d, %Y, %H:%M AoE')
def rows(name,fields):
 with (ROOT/'data'/name).open(newline='',encoding='utf-8-sig') as f:
  r=csv.DictReader(f)
  if r.fieldnames!=fields: raise ValueError(f'{name}: expected headers {fields}')
  result=[]
  for i,row in enumerate(r,2):
   if None in row or any(v is None for v in row.values()):raise ValueError(f'{name}:{i}: invalid column count')
   row={k:v.strip() for k,v in row.items()}
   if not any(row.values()):continue
   if not re.fullmatch(r'[A-Za-z0-9_]+',row['team_id']):raise ValueError(f'{name}:{i}: invalid team_id')
   result.append(row)
  return result
def scores(name,fields):
 data=rows(name,fields); seen=set()
 for r in data:
  if r['team_id'].lower() in seen:raise ValueError(f'{name}: duplicate team_id {r["team_id"]}')
  seen.add(r['team_id'].lower())
  for k in fields[1:]:
   r[k]=float(r[k])
   if not math.isfinite(r[k]) or not 0<=r[k]<=100:raise ValueError(f'{name}: {k} must be in [0,100]')
 return sorted(data,key=lambda r:tuple(-r[k] for k in fields[1:])+(r['team_id'],))
def table(data,fields,labels):
 if not data:return '<p class="empty">Rankings have not yet been published.</p>'
 result='<div class="table-wrap"><table><thead><tr><th scope="col">Rank</th>'+''.join('<th scope="col">'+escape(x)+'</th>' for x in labels)+'</tr></thead><tbody>'
 prev=None;rank=0
 for i,r in enumerate(data,1):
  key=tuple(r[k] for k in fields[1:])
  if key!=prev:rank=i
  prev=key
  result+=f'<tr><td>{rank}</td><th scope="row">{escape(r[fields[0]])}</th>'+''.join(f'<td>{r[k]:.4f}</td>' for k in fields[1:])+'</tr>'
 return result+'</tbody></table></div>'
def build():
 cfg=json.loads((ROOT/'data/settings.json').read_text())
 if cfg['leaderboard_status'] not in ['provisional','final','demo','baseline']:raise ValueError('leaderboard_status must be provisional, final, demo or baseline')
 if cfg['awards_status'] not in ['unpublished','published','demo']:raise ValueError('awards_status must be unpublished, published or demo')
 if cfg['updated_at']:
  date=datetime.fromisoformat(cfg['updated_at'].replace('Z','+00:00'))
  if date.tzinfo is None:raise ValueError('updated_at needs a timezone')
  stamp='<p class="updated">Last updated: '+escape(aoe_stamp(date))+'</p>'
 else:stamp=''
 t1=scores('task1.csv',['team_id','score']);t2=scores('task2.csv',['team_id','event_discovery_score','type_classification_accuracy'])
 awards=rows('awards.csv',['task','award','team_id','description'])
 for r in awards:
  if r['task'] not in ['task1','task2'] or not r['award']:raise ValueError('Awards require task1/task2 and an award title')
 if awards and cfg['awards_status']=='unpublished':raise ValueError('Awards rows exist but awards_status is unpublished; remove drafts before publishing')
 if cfg['awards_status'] in ['published','demo'] and not awards:raise ValueError('Published/demo awards need at least one row')
 leader='<p class="status">'+({'provisional':'Provisional rankings · subject to verification','final':'Final rankings','demo':'Pipeline test · illustrative predictions, not official rankings','baseline':'Baseline experiment · trained on public training data, not official rankings'}[cfg['leaderboard_status']])+'</p>'+stamp
 if cfg['leaderboard_status']=='baseline':
  leader+='<p class="subtitle">Frozen models evaluated on the test data. Task 2 results use the organizer-confirmed test labels.</p>'
 leader+='<section><h3>Task 1</h3><p class="subtitle">Social Group Discovery in Trending Events</p>'+table(t1,['team_id','score'],['Team','Group Discovery Score'])+'</section>'
 leader+='<section><h3>Task 2</h3><p class="subtitle">Open Event Detection in Social Media</p>'+table(t2,['team_id','event_discovery_score','type_classification_accuracy'],['Team','Event Discovery Score','Type Classification Accuracy (%)'])+'</section>'
 live=ROOT/'data/live-leaderboard.json'
 if live.exists():
  from sync_results import validate
  payload=validate(json.loads(live.read_text()))
  competition='<h3>Competition Leaderboard</h3><p class="status">Provisional rankings · subject to verification</p>'
  competition+='<p class="updated">Snapshot: '+escape(aoe_stamp(datetime.fromisoformat(payload['cycle'].replace('Z','+00:00'))))+' · Submission cutoff: '+escape(aoe_stamp(datetime.fromisoformat(payload['cutoff'].replace('Z','+00:00'))))+'</p>'
  for task,fields,labels in [('1',['score'],['Group Discovery Score']),('2',['event_discovery_score','type_classification_accuracy'],['Event Discovery Score','Type Classification Accuracy (%)'])]:
   entries=payload['tasks'][task]
   competition+='<section><h3>Task '+task+'</h3>'
   if not entries:competition+='<p class="empty">No competition submissions have been published for this cutoff.</p>'
   else:
    competition+='<div class="table-wrap"><table><thead><tr><th>Rank</th><th>Team</th>'+''.join('<th>'+escape(x)+'</th>' for x in labels)+'<th>Status</th></tr></thead><tbody>'
    for row in entries:
     status=row.get('status','valid')
     label={'valid':'Valid','invalid_submission':'Invalid submission','pending':'Pending evaluation','evaluation_error':'Evaluation pending review'}[status]
     competition+='<tr><td>'+(str(row['rank']) if status=='valid' else '—')+'</td><th scope="row">'+escape(row['team_id'])+'</th>'+''.join('<td>'+(format(row[k],'.4f') if status=='valid' else '—')+'</td>' for k in fields)+'<td>'+label+'</td></tr>'
    competition+='</tbody></table></div>'
   competition+='</section>'
  leader=competition
 award='<p class="status">Display test only · no official awards announced</p>' if cfg['awards_status']=='demo' else ''
 award+='<section><h3>Awards and Prizes</h3><p>'+escape(cfg['prize_description'])+'</p></section><section><h3>Award Results</h3>'
 if not awards:award+='<p class="empty">Award recipients have not yet been announced. Results will be announced on November 6, 2026, after verification.</p>'
 else:
  award_stamp=stamp
  if cfg.get('awards_updated_at'):
   awards_date=datetime.fromisoformat(cfg['awards_updated_at'].replace('Z','+00:00'))
   if awards_date.tzinfo is None:raise ValueError('awards_updated_at needs a timezone')
   award_stamp='<p class="updated">Last updated: '+escape(aoe_stamp(awards_date))+'</p>'
  award+=award_stamp+'<div class="table-wrap"><table><thead><tr><th>Task</th><th>Award</th><th>Team</th><th>Details</th></tr></thead><tbody>'
  for r in awards:award+='<tr>'+''.join('<td>'+escape(v)+'</td>' for v in [r['task'].replace('task','Task '),r['award'],r['team_id'],r['description']])+'</tr>'
  award+='</tbody></table></div>'
 award+='</section>'
 out=ROOT/'results';out.mkdir(exist_ok=True)
 css='''*{box-sizing:border-box}html,body{margin:0;background:transparent;color:#3c4c57;font:16px/1.8 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}main{padding:2px 0 12px}h3{font-size:20px;color:#17364a;margin:0 0 4px}p{margin:8px 0 14px}section+section{margin-top:28px}.subtitle,.updated{color:#72838c;font-size:13px}.status{display:inline-block;border:1px solid #eee1c9;border-left:3px solid #c39855;background:#fcf5e8;color:#775b2e;border-radius:5px;padding:8px 14px;margin:0 0 10px}.empty{padding:18px;background:#f1f5f8;border-radius:6px}.table-wrap{overflow:auto;border:1px solid #dde7ec;border-radius:6px;margin-top:16px}table{width:100%;border-collapse:collapse;font-size:14px;text-align:left;white-space:nowrap}th,td{padding:12px 15px;border-bottom:1px solid #dde7ec}thead th{background:#e9f1f5;color:#284c60}tbody th{font-weight:500}tr:last-child>*{border-bottom:0}tbody tr:hover{background:#f3f8fa}@media(max-width:600px){html,body{font-size:14px}h3{font-size:18px}th,td{padding:10px 12px}}'''
 (out/'style.css').write_text(css)
 for name,body in [('leaderboard',leader),('awards',award)]:
  js="""const send=()=>{const h=Math.ceil(document.querySelector('main').getBoundingClientRect().height)+8;parent.postMessage({type:'icdm-results-size',view:VIEW,height:h},ORIGIN)};new ResizeObserver(send).observe(document.querySelector('main'));addEventListener('load',send);""".replace('VIEW',json.dumps(name)).replace('ORIGIN','location.origin')
  (out/(name+'.js')).write_text(js)
  (out/(name+'.html')).write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ICDM 2026 '+name+'</title><link rel="stylesheet" href="style.css"></head><body><main>'+body+'</main><script src="'+name+'.js"></script></body></html>')
 (out/'index.html').write_text((out/'leaderboard.html').read_text())
 print(f'Built results: {len(t1)} Task 1 teams, {len(t2)} Task 2 teams, {len(awards)} awards.')
if __name__=='__main__':build()
