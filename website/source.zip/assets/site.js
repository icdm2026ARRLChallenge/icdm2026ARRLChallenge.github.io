(()=>{
 const legacy=document.body.dataset.singleSection;
 if(legacy){const hash=location.hash.slice(1);location.replace('../index.html#'+legacy+(hash&&hash!=='main-content'?'-'+hash:''));return;}
 const header=document.querySelector('.site-nav'),toggle=header?.querySelector('.nav-toggle'),nav=header?.querySelector('nav');
 if(!header||!toggle||!nav)return;
 const task=header.querySelector('.task-toggle'),menu=header.querySelector('.task-menu');
 const closeTask=()=>{if(task&&menu){task.setAttribute('aria-expanded','false');menu.hidden=true;}};
 const close=()=>{header.classList.remove('menu-open');toggle.setAttribute('aria-expanded','false');closeTask();};
 toggle.addEventListener('click',()=>{const open=header.classList.toggle('menu-open');toggle.setAttribute('aria-expanded',String(open));if(!open)closeTask();});
 task?.addEventListener('click',()=>{const open=task.getAttribute('aria-expanded')!=='true';task.setAttribute('aria-expanded',String(open));menu.hidden=!open;});
 nav.addEventListener('click',e=>{if(e.target.closest('a'))close();});
 document.addEventListener('click',e=>{if(!header.contains(e.target))close();});
 header.addEventListener('focusout',e=>{if(e.relatedTarget&&!header.contains(e.relatedTarget))close();});
 addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(task?.getAttribute('aria-expanded')==='true'){closeTask();task.focus();}else if(header.classList.contains('menu-open')){close();toggle.focus();}});
 matchMedia('(min-width: 992px)').addEventListener('change',close);
 const sections=['key-dates','task1','task2','registration','leaderboard'].map(id=>document.getElementById(id)).filter(Boolean);
 const links=[...nav.querySelectorAll('a')];
 const update=()=>{
  header.classList.toggle('scrolled',window.scrollY>24);
  if(!sections.length)return;
  const current=sections.filter(s=>s.getBoundingClientRect().top<=150).at(-1)?.id;
  links.forEach(a=>{const active=a.hash==='#'+current;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
  task?.classList.toggle('active',current==='task1'||current==='task2');
 };
 update();addEventListener('scroll',update,{passive:true});addEventListener('hashchange',update);
})();
