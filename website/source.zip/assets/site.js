(()=>{const header=document.querySelector('.site-nav'),toggle=header?.querySelector('.nav-toggle'),nav=header?.querySelector('nav');if(!header||!toggle||!nav)return;
 const update=()=>header.classList.toggle('scrolled',window.scrollY>24);update();addEventListener('scroll',update,{passive:true});
 const close=()=>{header.classList.remove('menu-open');toggle.setAttribute('aria-expanded','false');};
 toggle.addEventListener('click',()=>{const open=header.classList.toggle('menu-open');toggle.setAttribute('aria-expanded',String(open));});
 nav.addEventListener('click',e=>{if(e.target.closest('a'))close();});
 addEventListener('keydown',e=>{if(e.key==='Escape'&&header.classList.contains('menu-open')){close();toggle.focus();}});
 matchMedia('(min-width: 992px)').addEventListener('change',close);
})();
