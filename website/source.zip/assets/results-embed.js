(() => {
  const origin = location.origin;
  const frames = [...document.querySelectorAll('.live-results-frame')];
  window.addEventListener('message', event => {
    if (event.origin !== origin || event.data?.type !== 'icdm-results-size') return;
    const frame = frames.find(f => f.contentWindow === event.source && f.dataset.view === event.data.view);
    const height = event.data.height;
    if (frame && Number.isFinite(height) && height > 0) frame.style.height = Math.max(220, Math.min(20000, height)) + 'px';
  });
  frames.forEach(frame => {const url = new URL(frame.src); url.searchParams.set('v', Date.now()); frame.src = url.href;});
})();
