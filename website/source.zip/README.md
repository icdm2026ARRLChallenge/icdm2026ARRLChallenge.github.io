# ICDM 2026 public website

Static competition information only. Registration and submissions open the separate Tencent Cloud portal. No participant form or server implementation is deployed here.

## Frontend source and deployment

The authoritative frontend source is `website/source.zip` in this repository. The GitHub Pages workflow at `.github/workflows/pages.yml` extracts that archive into `website/`, synchronizes the signed leaderboard snapshot, and builds the public site. The build output is `website/_site/`.

To update website content:

1. Download and extract the current `website/source.zip` into a clean working directory.
2. Edit the relevant source files. The main competition content is in `index.html`; legacy pages redirect to its section anchors.
3. Validate locally with `python3 scripts/build_results.py` and `python3 scripts/package_public.py`.
4. Repackage the source files at the ZIP root (for example, `index.html`, `assets/`, `data/`, `pages/`, `results/`, and `scripts/`), without an extra enclosing folder. Preserve the existing source entries, including `.gitignore` and `.nojekyll`. Exclude `_site/`, caches, generated `data/live-leaderboard.json`, private files, and local test artifacts.
5. Replace `website/source.zip` on `main`. Wait for the GitHub Pages workflow to finish successfully, then verify the live website.

Do not update only loose files under `website/`: the workflow builds from `website/source.zip`. Preserve `task1/`, `task2/`, existing Releases, and the workflow when updating the archive.

## Scores and awards

Publish competition scores from the management portal. Publication queues an immediate GitHub synchronization; check its progress and final verification in the management portal. The frontend build verifies the signed snapshot before displaying scores. Do not manually edit leaderboard CSV files to replace management results.

For award configuration changes, edit the relevant files in `data/`, repackage `website/source.zip`, and push `main` using the deployment steps above.

Never put participant records, password hashes, private labels, submissions, signing private keys, tokens, or backups into this repository. Publish only the generated `_site/` output through GitHub Pages.
