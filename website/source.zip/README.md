# ICDM 2026 public website

Static competition information only. Registration and submissions open the separate Tencent Cloud portal. No participant form or server implementation is deployed here.

Place this folder in `website/` in the existing data repository; place `.github/workflows/pages.yml` at the repository root. Preserve task1/, task2/ and existing Releases.

Run `python3 scripts/build_results.py` then `python3 scripts/package_public.py`. Publish only `_site/` with GitHub Pages. Edit public CSVs in data/ and push main to rebuild the public leaderboard and prizes. Never put participant records, password hashes, private labels, submissions or backups into this repository.

The public website is a single page. Edit index.html for task content and section anchors. Legacy pages are retained as redirect sources. The build embeds the signed leaderboard into the homepage.
